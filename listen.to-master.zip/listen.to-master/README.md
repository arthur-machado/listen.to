# listen.to

## Instalação

Pra deixar tudo pronto pra rodar, tu vai precisar entrar na pasta do app (listen-to-app) e digitar o seguinte:

```
npm install express
```
Depois que o express tiver instalado, tu digita:

```
npm install 
```

E aí ele instala todas as dependências que tão dentro do package.json 

Pra rodar e ver se tá funcionando, digitar:
```
npm start
```

No navegador, acessa [http://localhost:3000](http://localhost:3000) e um "Welcome to express" deve aparecer
